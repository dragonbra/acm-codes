clear
[num]=xlsread('D:\GitHub\acm-codes\��ģ\data.xls');

input = num(:,4:9);
output = num(:,3);

input_test = input(67:167,:);
output_test = output(67:167,:);